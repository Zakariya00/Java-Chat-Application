1. download the code in projektarbete2
2. upload all files to the src folder of your intellij project




