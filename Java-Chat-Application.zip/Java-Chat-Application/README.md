# Java-Chat-Application
3 Java Client-Server Chat Applications, example1, example2, example3. They do the same thing, but in different ways. Based on tutorials from youtube.
